Greetings to all,
to run Chunkmapper from the command line type

java -Xmx1G -jar Chunkmapper.jar

Ubuntu users must use at least Oracle Java 7 update 51 to avoid bugs.
