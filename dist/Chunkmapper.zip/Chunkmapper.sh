java -Xmx1G -jar Chunkmapper.jar
